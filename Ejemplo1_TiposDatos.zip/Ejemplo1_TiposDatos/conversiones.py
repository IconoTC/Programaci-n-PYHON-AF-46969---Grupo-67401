import math

# convertir texto a numero entero
numero1 = int(input("Introduce un numero: "))
numero2 = int(input("Introduce otro numero: "))
suma = numero1 + numero2
print("Suma:", suma)

# convertir texto a numero real
radio = float(input("Introduce radio del circulo: "))
area = math.pi * radio**2
area2 = math.pi * math.pow(radio, 2) 
print("Area del circulo:", area)

# funcion round(numero, numDecimales)
print("Area del circulo:", round(area2, 3))

# convertir un booleano en entero
# True = 1, False = 0
soltero = True
hijos = False
print("Soltero:", soltero, "Hijos:", hijos)
print("Soltero:", int(soltero), "Hijos:", int(hijos))

# convertir un entero a booleano
print(bool(1))  # True
print(bool(0))  # False

# Pero todo valor distinto de 0 da True
print(bool(5))  # True
print(bool(5.6)) # True
print(bool(-5))  # True

# Converiones a texto
texto = str(numero1)
print("Texto:", texto, "Tipo:", type(texto))
texto = str(radio)
print("Texto:", texto, "Tipo:", type(texto))
texto = str(soltero)
print("Texto:" + texto + "Tipo:" + str(type(texto)))