'''
    Solicitar 2 numeros al usuario
    limpiar si hay espacios en blanco
    Mostrar suma, resta, multiplicacion, ..... utilizar upper()
    Tratar de utilizar los parametros end y sep de print
'''

numero1 = float(input("Introduce un numero: ").strip().replace(",",".")) 
numero2 = float(input("Introduce un numero: ").strip()) 

print("suma:".upper(), numero1 + numero2)
print("resta:".upper(), round(numero1 - numero2, 2))
print("multiplicacion:".upper(), round(numero1 * numero2, 2))
print("division:".upper(), round(numero1 / numero2, 2))
print("division entera:".upper(), round(numero1 // numero2, 2))
print("resto de division:".upper(), round(numero1 % numero2, 2))
print("potencia:".upper(), round(numero1 ** numero2, 2))