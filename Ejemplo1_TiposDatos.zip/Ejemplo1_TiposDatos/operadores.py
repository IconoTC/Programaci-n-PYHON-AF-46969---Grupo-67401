# Operadores aritmeticos (+,-,*,/,%,**,//)
numero1 = 7
numero2 = 2
print("Division:", 7/2)  # Division: 3.5
print("Division entera:", 7//2) # Division entera: 3
print("Resto de la division:", 7%2)  # Resto de la division: 1
print("Potencia:", 7**2) # Potencia: 49

# Operadores asignacion (+=,-=,*=,/=,%=,**=,//=)
num = 6
num += 5     # num = num + 5

# En Python no existen los incrementos, ni decrementos
num += 1    # num++
num -= 1    # num--

# Operadores de comparacion (<,>,<=,>=,==,!=)
print(numero1 > numero2)
print(numero1 >= 7)
print(numero1 == 7)
print(numero1 != 7)

# Operadores logicos (and,or,not)
print(numero1 > 0 and numero2 == 2)  # True se cumplen las 2 condiciones
print(numero1 > 0 or numero2 == 5)  # True se cumple al menos 1 condicion
print(numero2 == 5)  # False
print(not  numero2 == 5)  # True   no es necesario poner parentesis
print(not(numero2 == 5))  # True

# Operadores de identidad (is, is not)
num1 = 6
num2 = 6
print("Es el mismo contenido", num1 is num2)  # True  estoy comparando datos simples
print("Es el mismo contenido", num1 == num2)  # True

nombres1 = ['Juan', 'Maria']   # nombres1 = 0x1234
nombres2 = ['Juan', 'Maria']   # nombres2 = 0xd3c9
print("Es el mismo objeto", nombres1 is nombres2)   # False porque son objetos distintos
print("Son diferentes objetos", nombres1 is not nombres2)  # True
print("Es el mismo contenido", nombres1 == nombres2) # True compara lista con lista


# Operadores de pertenencia (in, not in)
print('Luis' in nombres1)  # False
print('Juan' in nombres1)  # True
print('Luis' not in nombres1)