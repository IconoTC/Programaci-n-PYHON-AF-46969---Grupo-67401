texto = "bienvenidos al curso de Python"

print("capitalize()", texto.capitalize()) # Bienvenidos al curso de python
print("title()", texto.title()) # Bienvenidos Al Curso De Python
print("upper()", texto.upper()) # BIENVENIDOS AL CURSO DE PYTHON
print("lower()", texto.lower()) # bienvenidos al curso de python
print("swapcase()", texto.swapcase()) # BIENVENIDOS AL CURSO DE pYTHON

print("alphanumerico", texto.isalnum()) # False por los espacios en blanco (" ", \t, \n)
print("alphanumerico", "Pepito".isalnum())  # True
print("alphanumerico", "12345".isalnum())   # True

print("alphabetico", texto.isalpha()) # False por los espacios en blanco (" ", \t, \n)
print("alphanumerico", "Pepito".isalpha())  # True
print("alphanumerico", "12345".isalpha())   # False

print("digitos", texto.isdigit())  # False por los caracteres
print("alphanumerico", "Pepito".isdigit())  # False
print("alphanumerico", "12345".isdigit())   # True

print("mayusculas", texto.isupper())  # False
print("mayusculas", "HOLA".isupper())  # True
print("mayusculas", "caracola".isupper()) # False

print("minusculas", texto.islower())  # False
print("minusculas", "HOLA".islower())  # False
print("minusculas", "caracola".islower()) # True

ejemplo = "     lunes    "
print("lstrip", ejemplo.lstrip(), end=".\n") # lstrip lunes    .
print("rstrip", ejemplo.rstrip(), end=".\n") # rstrip      lunes.
print("strip", ejemplo.strip(), end=".\n") # strip lunes.

print("longitud", len(texto)) # longitud 30
print("longitud", texto.__len__())  # longitud 30

print("maximo", max(texto)) # maximo y
print("minimo", min(texto), end=".\n") # minimo  .   Espacio en blanco

print("replace", texto.replace('e','E')) # cambia todas replace biEnvEnidos al curso dE Python
print("replace", texto.replace('e','E', 1)) # solo cambia 1  replace biEnvenidos al curso de Python

print("find", texto.find('e')) # find 2
print("rfind", texto.rfind('e')) # rfind 22
print("find", texto.find('w')) # si no lo encuentra retorna -1

print("index", texto.index('e'))  # index 2
#print("index", texto.index('w')) # si no lo encuentra genera error ValueError: substring not found

print("comienza con bien", texto.startswith("bien")) # comienza con bien True
print("termina con python", texto.endswith("python")) # termina con python False (case sensitive)

palabras = texto.split() # por defecto corta por el espacio
print(palabras)  # es una lista  ['bienvenidos', 'al', 'curso', 'de', 'Python']

cadena = "-".join(palabras)
print(cadena)  # bienvenidos-al-curso-de-Python