# abrir un fichero en modo escritura
fichero = open("Ejemplo8_Ficheros_Texto/texto.txt", "wt", encoding="utf-8")

# Agregar texto hasta que el usuario escriba FIN
texto = ""
while (texto != "FIN"):
    texto = input("Introduce texto, (FIN) para terminar: ")
    if texto == "FIN":
        break
    fichero.write(texto + "\n")
    
# cerrar el fichero
fichero.close()