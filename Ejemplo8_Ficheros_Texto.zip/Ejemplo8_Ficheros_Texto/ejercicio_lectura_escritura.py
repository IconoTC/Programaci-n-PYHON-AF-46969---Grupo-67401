'''
    se trata de leer el fichero texto.txt
    y escribir el contenido en otro texto2.txt
    
    al final teneis que mostrar el contenido de texto2.txt
'''
# abrir el fichero en modo lectura
f_read = open("Ejemplo8_Ficheros_Texto/texto.txt", "rt", encoding="utf-8")

#abrir el fichero en modo lectura y escritura
f_write = open("Ejemplo8_Ficheros_Texto/texto2.txt", "w+t", encoding="utf-8")

# leer todo el contenido del fichero texto.txt
lista = f_read.readlines()

# escribir cada linea en el fichero texto2.txt
for linea in lista:
    f_write.write(linea)
    
# leer el contenido creado
f_write.seek(0)
for linea in f_write:
    print(linea, end="")