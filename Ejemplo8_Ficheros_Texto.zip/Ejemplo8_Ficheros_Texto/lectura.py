# abrir un fichero en modo lectura
fichero = open("Ejemplo8_Ficheros_Texto/texto.txt", "rt", encoding="utf-8")

# leer todo el contenido en una variable de tipo str
texto = fichero.read()
print(texto)

# mover el puntero al inicio, al primer caracter
fichero.seek(0)

# leer todo el contenido en una lista, cada linea es un elemento de la lista
lista = fichero.readlines()
print(lista)

# leer los primeros 3 caracteres
fichero.seek(0)
palabra = fichero.readline(3)
print(palabra + " ----------------")

# Tambien lo podemos hacer con read()
fichero.seek(0)
palabra = fichero.read(3)
print(palabra)

# leer la primera linea
fichero.seek(0)
linea_1 = fichero.readline()
print(linea_1)

# Otra opcion para crear una lista con el contenido del fichero
fichero.seek(0)
lista = list(fichero)
print(lista)

# cerrar el fichero
fichero.close()