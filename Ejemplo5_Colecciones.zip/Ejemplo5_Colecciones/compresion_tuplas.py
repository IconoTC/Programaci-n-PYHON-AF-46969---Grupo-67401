# Ejemplo 1
# Con la lista de numeros crear una tupla 2d (num, cuadrado del numero)
# ( (1,1), (2,4), (3,9), (4,16), (5,25)  )
numeros = [1,2,3,4,5]
tuple_2d = tuple((num, num**2) for num in numeros)

# Ejemplo 2
lista_tuplas = []
for x in [0.4, 1.5, 5]:
    for y in [-1.2, 0.2, -2.4]:
        if x > y:
            lista_tuplas.append( (x,y) )
print(lista_tuplas)

lista_tuplas = [(x,y)  for x in [0.4, 1.5, 5] for y in [-1.2, 0.2, -2.4] if x > y ]
print(lista_tuplas)