# listas: colecciones ordenadas de elementos
# en todas las colecciones los elementos pueden ser de diferentes tipos
# permiten tener elementos duplicados
# son mutables, permiten modificaciones
# Se crean con []

colores = ['rojo', 'verde', 'azul']
print(type(colores))  # list

# Mostrar la lista
print(colores)

# Longitud de la lista
print(len(colores))
print(colores.__len__())

# Ordenar la lista, la muestra, no la modifica
print(sorted(colores)) # ascendente
print(sorted(colores, reverse=True)) # descendente

# Accedemos a los elementos por indice
print(colores[1])

# borrar un elemento por posicion
del colores[2]    # borrar azul
print(colores)

# Concatenar listas
mas_colores = ['blanco', 'negro', 'rosa', 'azul']
nueva_lista = colores + mas_colores
print(nueva_lista)

# borrar un elemento por elemento
nueva_lista.remove('rosa')  # solo borra el primero encontrado
print(nueva_lista)

# otra forma de borrar por indice
nueva_lista.__delitem__(4)  # hemos borrado azul con indice 4
print(nueva_lista)

# Añadir un elemento al final
nueva_lista.append('naranja')
print(nueva_lista)

# Insertar un elemento en la posicion indicada
nueva_lista.insert(0, 'marron')
print(nueva_lista)

# Cuantos elementos tienes repetidos
print(nueva_lista.count('verde'))

# Mostrar el indice de un elemento
print(nueva_lista.index('verde'))

# Mostrar el ultimo elemento
print(nueva_lista[ len(nueva_lista) - 1 ])
print(nueva_lista[ -1 ])

# Mostrar el tercero empezando por el final 
print(nueva_lista[ -3 ])

'''   slices [inicio:fin:step]   '''
# Mostrar los 3 ultimos
print(nueva_lista[-3:])

# Mostrar los 3 primeros
print(nueva_lista[:3])  # el ultimo queda excluido 0,1,2

# Mostrar desde la posicion 2 a la 3
print(nueva_lista[2:4])

# Mostrar todos
print(nueva_lista[:])

# Mostrar todos en orden descendente
print(nueva_lista[::-1])

# Mostrar todos de 2 en 2
print(nueva_lista[::2])

# Elimina todos los elementos de la lista
nueva_lista.clear()
print(nueva_lista)


# listas de 2 dimensiones
matriz = [ [1,2,3], [4,5,6], [7,8,9] ]