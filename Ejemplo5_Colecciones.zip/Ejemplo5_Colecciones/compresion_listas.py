# Ejemplo 1
lista_palabras = ['casa', 'mesa', 'manzana', 'pijama']
longitud_palabras = []   # lista = list()

for palabra in lista_palabras:
    longitud_palabras.append(len(palabra))
    
print(longitud_palabras)

''' compresion de listas '''
longitud_palabras = [len(palabra)  for palabra in lista_palabras]
print(longitud_palabras)


# Ejemplo 2
# crear una lista con numeros pares del 0 al 10
numeros_pares = [num  for num in range(0,11) if num % 2 == 0 ]
print(numeros_pares)


# Ejemplo 3
# Dado ese vector crear una lista solo con los numeros impares
vector = [ [1,2,3], [4,5,6], [7,8,9] ]
numeros_impares = [num  for fila in vector     for num in fila   if num % 2 != 0 ]
print(numeros_impares)

# Intentar devolver la lista de de 2 dimensiones: [ [1,3], [5], [7,9] ]
numeros_impares = []
for fila in vector:
    fila_impares = []
    for num in fila:
        if num % 2 != 0:
            fila_impares.append(num)
    numeros_impares.append(fila_impares)
print(numeros_impares)

numeros_impares = [ [num for num in fila  if num % 2 != 0]  for fila in vector ]
print(numeros_impares)

# Ejemplo 4
# Con esta matriz devolver una lista con 2 filas [[1,3,5,7],[2,4,6,8]]
matriz = [ [1,2],[3,4],[5,6],[7,8]]
nueva_matriz = [ [row[0] for row in matriz], [row[1] for row in matriz] ]
print(nueva_matriz)

nueva_matriz = [ [fila[i] for fila in matriz]  for i in range(len(matriz[0])) ]
print(nueva_matriz)

impares_pares = [[num for fila in matriz for num in fila if num % 2 != 0], [num for fila in matriz for num in fila if num % 2 == 0]]
print(impares_pares)