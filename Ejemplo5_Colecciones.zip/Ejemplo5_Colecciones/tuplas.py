# tuplas: colecciones ordenadas (con indice) pero son inmutables
# si se permiten elementos duplicados
# Se crean con ()
# Ejemplos de uso: meses del año, dias de la semana, estado civil, puntos cardinales

dias = ('lunes','martes','miercoles','jueves','viernes','sabado','domingo')
print(type(dias))   # tuple

# Formas de crear una tupla vacia
tupla_vacia = ()
tupla_vacia = tuple()

# Mostrar el miercoles
print(dias[2])

#TypeError: 'tuple' object doesn't support item deletion
#del dias[0]

# TypeError: 'tuple' object does not support item assignment
# dias[0] = "sabado"

# longitud de la tupla
print(len(dias))
print(dias.__len__())

# Cuantos domingos hay
print(dias.count('domingo'))

# Buscar la posicion del viernes
print(dias.index('viernes'))
print(dias.index('viernes', 2))

# Concatenar tuplas en una tupla diferente
# TypeError: can only concatenate tuple (not "int") to tuple
# otra_tupla = dias + (1)

# Para concatenar tuplas ha de tener varios elementos o forzar al interprete para que lo vea como tupla
otra_tupla = dias + (1,)   # Funciona
otra_tupla = dias + (1,2,3,4,5)
print(otra_tupla)

# tuplas de 2 dimensiones
tupla_2d = (('Juan', 27, 'Soltero'), ('Maria',), ('Luis', 43, 'Casado', '2 hijos') )
for empleado in tupla_2d:
    for dato in empleado:
        print(dato, end=" ")
    print()
    
'''  slices [begin:stop:step]  '''
# mostrar los dias de lunes a viernes
print(dias[:5])

# mostrar de viernes a domingo
print(dias[-3:])

# Convertir una tupla en lista
lista_dias = list(dias)
print(lista_dias)

# Crear una tupla a partir de una lista
tupla_numeros = tuple([1,2,3,4,5])
print(tupla_numeros)

# Curioso, como tambien podemos crear tuplas
tupla_numeros = 1,2,3,4,5
print(tupla_numeros)
