# Ejemplo 1
# crear un conjunto con las letras de la palabra 'abracadabra'
# que no sean a,b,c

# compresion
conjunto = {letra  for letra in 'abracadabra' if letra not in {'a','b','c'} }
print(conjunto)


# utilizando operaciones de conjuntos
conjunto = {'a','b','r','a','c','a','d','a','b','r','a'}
print(conjunto.difference({'a','b','c'}))