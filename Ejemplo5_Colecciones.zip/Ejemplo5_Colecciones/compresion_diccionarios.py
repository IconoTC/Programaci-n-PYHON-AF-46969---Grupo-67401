# Ejemplo 1
#  crear una lista con las vocales
# utilizando compresion, crear un diccionario donde:
#   la clave es el indice de la lista
#   el valor es la letra
lista = ['a','e','i','o','u']
resultado = {indice:lista[indice]  for indice in range(len(lista)) }
print(resultado)


# Ejemplo 2
# la funcion enumerate(lista) retorna el indice y el elemento de la lista
for k, v in enumerate(lista):
    print(k, ":", v)
    
resultado = {k:v  for k, v in enumerate(lista)}
print(resultado)