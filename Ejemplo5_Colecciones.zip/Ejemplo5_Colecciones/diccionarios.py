# diccionarios: los elementos son clave:valor
# No tienen indices y se accede a ellos a través de la clave
# A partir de Python 3.7 se garantiza el orden de entrada
# Las claves no se pueden repetir, pero los valores si
# Si se repite una clave, se sobreescribe el valor
# Son mutables, permiten agregar, borrar, modificar
# Se crean con {}

alumnos = {'Juan': 6.4, 'Maria': 8.3, 'Luis': 6.4, 'Adolfo': 7.1, 'Maria': 9.3}
print(type(alumnos))  # dict
print(alumnos)

# Mostrar solo los nombres (claves)
print(alumnos.keys())
for nombre in alumnos.keys():
    print(nombre)

# Mostrar solo las notas (valores)
print(alumnos.values())

# Motrar todos los elementos
print(alumnos.items())

# Accedemos a los elementos por su clave
print("Nota la Luis:", alumnos['Luis']) # Si no existe esa clave -> KeyError
print("Nota la Luis:", alumnos.get('Luis')) # Si no existe esa clave -> None 
print("Nota la Luis:", alumnos.get('Luisssss', 'Clave no encontrada'))  # Nota la Luis: Clave no encontrada

# Borrar un elemento
# del alumnos['Adolfo']   Funciona
alumnos.__delitem__('Adolfo')   # Tambien funciona
# En ambos casos del y delitem si no existe esa clave keyError
print(alumnos)

# Agregar nuevo elemento
alumnos['Pepito'] = 3.5
print(alumnos)

# Modificar el valor de un elemento
alumnos['Pepito'] = 5
print(alumnos)

# Otra forma de agregar elementos al diccionario
alumnos.update({'Pepito': 6})
print(alumnos)


# Recorrer un diccionario
for alum in alumnos:  # solo me devuelve las claves
    print(alum, alumnos[alum])
    
for item in alumnos.items():  # cada item es una tupla (clave, valor)
    print(item)
    
for k, v in alumnos.items():
    print(k, ":", v)

  
# Otras formas de crear diccionarios
alumnos = dict()
alumnos = {}
# crear un diccionario a partir de una lista de tuplas
alumnos = dict([('Juan',6.4), ('Maria',8.3), ('Luis',6.4), ('Adolfo',7.1), ('Maria',9.3)])
# alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1, Maria=9.3)   # los repetidos asi no los admite
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)