# conjuntos: colecciones sin orden, no usamos indices
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Son mutables, permiten agregar, eliminar
# Se crean con {}
# Cuidado porque conjunto={} se interpreta como un diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas))  # set

# crear un conjunto vacio
conjunto = {}
print(type(conjunto))  # dict
conjunto = set()
print(type(conjunto))  # set

# Mostrar frutas y vemos que no tiene duplicados
print(frutas)

# agregar fresas
frutas.add('fresas')
print(frutas)

# eliminar platano
frutas.remove('platano')
print(frutas)

# longitud
print(len(frutas))
print(frutas.__len__())

# Recorrer conjuntos
for fruta in frutas:
    print(fruta, end=" ")
print()

