'''
    Crear un funcion que recibe un texto y retorna:
        - el texto en mayusculas
        - el texto en minusculas
        - la longitud del texto
'''

def procesar_texto(texto: str): 
    # pass  funcion vacia sin cuerpo
    mayusculas = texto.upper()
    minusculas = texto.lower()
    longitud = len(texto)
    return mayusculas, minusculas, longitud
    

# recuperar los datos con multiples variables
txt_may, txt_min, txt_len = procesar_texto('Buenos dias amigos')
print(txt_may)
print(txt_min)
print(txt_len)


# recuperar los datos con una lista
lista = procesar_texto('Buenos dias amigos')
for dato in lista:
    print(dato)