def datos_trabajador(nombre, estado_civil="Soltero", sueldo=24000):
    #print(nombre, "su sueldo es", sueldo)
    print(f"{nombre} esta {estado_civil} y su sueldo es {sueldo}")
    
datos_trabajador(nombre="Juan")
# Error
datos_trabajador("Maria", 35000) # Maria esta 35000 y su sueldo es 24000
datos_trabajador("Maria", sueldo=35000) # Maria esta Soltero y su sueldo es 35000

'''
    crear una funcion concatenar que recibe los dias de la semana como *args
    y tambien un texto que actue como separador
    retornar los dias con el separador (join)
'''
def concatenar(*dias, separador="-"):
    return separador.join(dias)

print(concatenar('lunes','martes','miercoles','jueves','viernes','sabado','domingo'))
print(concatenar('lunes','martes','miercoles','jueves','viernes','sabado','domingo', separador=" | "))
print(concatenar('lunes','martes','miercoles','jueves','viernes','sabado','domingo', separador="/"))