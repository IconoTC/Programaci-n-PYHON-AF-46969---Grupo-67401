# Funcion que acepte distinto numero de argumentos
def sumar(*numeros):    # numeros es una tupla, una coleccion
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(7))
print(sumar(7, 2))
print(sumar(7, 2, 5))
print(sumar(7, 2, 5, 9))


'''
    crear una funcion que recibe el nombre y las notas de un alumno
    utilizando la funcion sumar() calcular la nota media
    devolver por un lado el nombre en mayusculas y la nota media
'''
'''
# el argumento variable tiene que ir al final
# solo puede haber 1
def procesar_notas(nombre, *notas):
    nota_media = sumar(*notas) / len(notas)
    return nombre.upper(), round(nota_media, 2)

print(procesar_notas("Juan", 2,5,3))
print(procesar_notas("Maria", 9,8))
print(procesar_notas("Pedro", 7,5,9,6))
'''

# Si utilizas el nombre del argumento puede ir al final
# Pero solo puede haber un argumento variable 
def procesar_notas(*notas, nombre):
    nota_media = sumar(*notas) / len(notas)
    if nombre != None:
        nombre = nombre.upper()
    return nombre, round(nota_media, 2)

print(procesar_notas(2,5,3, nombre="Juan"))
print(procesar_notas(9,8, nombre="Maria"))
print(procesar_notas(7,5,9,6, nombre=None))