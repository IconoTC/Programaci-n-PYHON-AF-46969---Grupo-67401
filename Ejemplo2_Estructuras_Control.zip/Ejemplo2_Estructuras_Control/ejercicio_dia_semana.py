'''
    El usuario introduce una letra (l,m,x,j,v,s,d) le decimos a que dia de la semana pertenece
    Puede ser mayuscula o minuscula
'''

letra = input("Introduce una letra (l,m,x,j,v,s,d): ")

if letra == 'l' or letra == 'L':
    print("Es lunes")
elif letra.upper() == 'M':
    print("Es martes")
elif letra.lower() == 'x':
    print("Es miercoles")
elif letra.lower() in 'j':
    print("Es jueves")
elif letra.lower() == 'v':
    print("Es viernes")
elif letra.lower() == 's':
    print("Es sabado")
elif letra.lower() == 'd':
    print("Es domingo")
else:
    print("Dia desconocido")