nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

for item in nombres:
    print(item)
print("----- FIN -----")

''' rangos '''
# Mostrar los numeros del 0 al 9
for numero in range(10):   # rango va desde 0 hasta numero-1
    print(numero, end=" ")
print()

# Mostrar los numeros del 1 al 10
for numero in range(1,11): 
    print(numero)
print("----- FIN -----")

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0,11,2):
    print(numero)
print("----- FIN -----")

# Mostrar los numeros de 10 a 1
for numero in range(10, 0, -1):
    print(numero)
print("----- FIN -----")  

# Recorrer la lista mostrando cada nombre utilizando indices
# len(lista) -> nos devuelve el numero de elementos 
# De forma ascendente
for indice in range(len(nombres)): # va 0 a longitud-1    rango de 0 a 4
    print(nombres[indice])
print("----- FIN -----") 

# De forma descendente
for indice in range(len(nombres)-1, -1, -1):
    print(nombres[indice])
print("----- FIN -----") 