'''
    El usuario introduce una letra (l,m,x,j,v,s,d) le decimos a que dia de la semana pertenece
    Puede ser mayuscula o minuscula
'''

letra = input("Introduce una letra (l,m,x,j,v,s,d): ")

match letra:
    case 'l' | 'L':
        print("Es lunes")
    case 'm':
        print("Es martes")
    case 'x':
        print("Es miercoles")
    case 'j':
        print("Es jueves")
    case 'v':
        print("Es viernes")
    case 's':
        print("Es sabado")
    case 'd':
        print("Es domingo")
    case _:
        print("Dia desconocido")