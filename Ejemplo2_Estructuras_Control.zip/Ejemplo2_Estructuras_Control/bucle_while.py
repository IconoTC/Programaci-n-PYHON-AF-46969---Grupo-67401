# mostrar los numeros del 1 al 10
num = 1
while num <= 10:
    print(num)
    num += 1
print("****** FIN ******")


# recorrer una lista
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']
idx = 0
while idx < len(nombres):
    print(nombres[idx])
    idx += 1
print("****** FIN ******")