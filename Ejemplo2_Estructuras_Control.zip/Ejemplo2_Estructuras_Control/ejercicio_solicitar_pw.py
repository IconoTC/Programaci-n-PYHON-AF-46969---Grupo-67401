'''
    Solicitar el pw al usuario hasta que adivine que es 'curso'
    Solo tiene 3 intentos
    
    break; da por finalizado el bucle
    continue; da por terminada esa iteraccion y pasa a la siguiente
'''

# Version 1
for intento in range(3):
    pw = input("Introduce pw: ")
    if pw == 'curso':
        print("PW correcta")
        break
    else:
        print("PW incorrecto, te quedan", 2-intento, "intentos")

        
# Version 2
intentos = 0
while intentos < 3:
    pw = input("Introduce pw: ")
    if pw == 'curso':
        print("PW correcta")
        break
    else:
        print("PW incorrecto, te quedan", 2-intentos, "intentos")
    intentos += 1
   