'''
    si la condicion: edad >= 18 
        se evalua como True no hace nada
        se evalua como False lanza un AssertionError
'''

edad = int(input("Introduce tu edad: "))
# assert edad >= 18
assert edad >= 18, "Eres menor de edad"

print("El programa continua")