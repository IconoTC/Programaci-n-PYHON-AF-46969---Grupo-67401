# try-except-else-finally
import sys
import traceback

try:
    dividendo = int(input("Introduce dividendo: "))
    divisor = int(input("Introduce divisor: "))
    division = dividendo / divisor
except ValueError as e:
    print(e) # invalid literal for int() with base 10: 'dos'  ->  mensaje
    print(e.args) # ("invalid literal for int() with base 10: 'dos'",)  -> tupla
    print(e.with_traceback())  # -> Traceback (most recent call last):
    print("El valor introducido no es numerico")
except ZeroDivisionError:
    # Mostrar el mensaje como error
    sys.stderr.write("Error, division por 0")
    print("No se puede dividir por 0")
    traceback.print_exc()
except Exception:
    print("Ha ocurrido un error")
else:
    # Se ejecuta cuando no ha habido excepciones
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya o no excepciones
    print("******** FIN *******")