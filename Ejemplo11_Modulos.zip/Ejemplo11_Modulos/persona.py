'''
    Este es el modulo que contiene la clase Persona
'''
class Persona: 
    def __init__(self, nombre: str, edad: int):
        self.nombre = nombre 
        self.edad = edad
        
    def __str__(self):
        return f"Hola, me llamo {self.nombre}, tengo {self.edad} años"