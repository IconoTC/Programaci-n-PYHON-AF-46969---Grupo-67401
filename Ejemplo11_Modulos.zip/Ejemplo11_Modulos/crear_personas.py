# Primera forma, importamos el modulo entero
import persona

# Sintaxis: modulo.recurso
juan = persona.Persona("Juan",46)
print(juan)


# Segunda forma, importamos solo el recurso que necesitamos
from persona import Persona

# Sintaxis: recurso
maria = Persona("Maria", 29)
print(maria)

# Tercera forma, importamos solo el recurso que necesitamos con alias
from persona import Persona as Person

# Sintaxis: alias
javier = Person("Javier", 36)
print(javier)