
# Abrir el fichero en modo lectura
fichero = open("Ejemplo9_Ficheros_Binarios/fichero.bin", "rb")

# Recuperar el contenido y lo decodificamos
dias = fichero.read()
dias_decode = dias.decode("utf-8")
print(dias_decode)

# Recuperar el contenido y lo decodificamos
#mensaje = bytearray(fichero.read())
#print(mensaje.decode())

# Cerrar el fichero
fichero.close()