import pickle

# Abrir el fichero en modo lectura
fichero = open("Ejemplo9_Ficheros_Binarios/fichero.pckl", "rb")

# Recuperar el contenido
dias = pickle.load(fichero)

# Mostrar el contenido y el tipo
print(dias)
print(type(dias))

# Cerrar el fichero
fichero.close()