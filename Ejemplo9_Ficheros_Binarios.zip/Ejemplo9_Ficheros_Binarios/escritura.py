
# Abrir el fichero en modo escritura y binario
fichero = open("Ejemplo9_Ficheros_Binarios/fichero.bin", "wb")

dias = ['lunes','martes','miercoles','jueves','viernes','sabado','domingo']

# Escribimos la lista en el fichero
#fichero.write(dias) # TypeError: a bytes-like object is required, not 'list'

# tengo que convertir la lista a bytes
fichero.write(bytes(str(dias), "utf-8"))
# fichero.write(bytearray(b'hola'))  FUNCIONA

# Cerrar el fichero
fichero.close()