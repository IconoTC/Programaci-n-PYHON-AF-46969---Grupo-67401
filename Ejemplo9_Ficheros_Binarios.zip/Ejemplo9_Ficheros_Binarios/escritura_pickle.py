import pickle

dias = ['lunes','martes','miercoles','jueves','viernes','sabado','domingo']

# Abrir el fichero en modo escritura y binario
fichero = open("Ejemplo9_Ficheros_Binarios/fichero.pckl", "wb")

# Escribimos la lista en el fichero
pickle.dump(dias, fichero)

# Cerrar el fichero
fichero.close()