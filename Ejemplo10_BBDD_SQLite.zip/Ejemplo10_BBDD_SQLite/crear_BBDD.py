''' Crear la BBDD y la tabla  '''
import sqlite3

# Crear la BBDD
# Abrir una conexion, si no existe la BBDD se crea
conexion = sqlite3.connect("Ejemplo10_BBDD_SQLite/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

# Crear la tabla
query = "CREATE TABLE PRODUCTOS (codigo INTEGER PRIMARY KEY, descripcion TEXT, precio REAL)"
cursor.execute(query)

# MUY IMPORTANTE EL COMMIT
conexion.commit()

# Cerrar la conexion
conexion.close()