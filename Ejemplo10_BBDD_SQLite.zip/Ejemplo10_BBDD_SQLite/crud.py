import sqlite3

# Abrir una conexion
conexion = sqlite3.connect("Ejemplo10_BBDD_SQLite/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()


''' ************************* Insertar datos *************************** '''
# Insertar un solo registro
#cursor.execute("INSERT INTO PRODUCTOS values (1, 'Pantalla', 129.95)")

# Insertar varios registros en una lista de tuplas
lista = [(2, 'Teclado', 48.50), (3, 'Raton', 17), (4, 'Impresora', 89.90)]
query = "INSERT INTO PRODUCTOS values (?,?,?)"
#cursor.executemany(query, lista)


''' ************************* Consultas de datos *************************** '''
# Consultar todos los productos
cursor.execute("SELECT * FROM PRODUCTOS")
productos = cursor.fetchall()  # Recoje todos los resultados obtenidos
for prod in productos:  # prod es una tupla
    print("Codigo:", prod[0], "Descripcion:", prod[1], "Precio:", prod[2])
print("--- FIN ---")

# Buscar un producto
cursor.execute("SELECT * FROM PRODUCTOS where codigo=1")
pantalla = cursor.fetchall()  # devuelve una lista de tuplas
print(pantalla)
print("--- FIN ---")

# Buscar un producto con parametros
# los parametros se pasan en una tupla (1,)
cursor.execute("SELECT * FROM PRODUCTOS where codigo=?", (1,))
pantalla = cursor.fetchone()   # devuelve la tupla
print(pantalla)
print("--- FIN ---")

cursor.execute("SELECT * FROM PRODUCTOS where codigo IN (?,?,?)", (1,2,3))
productos = cursor.fetchall()
print(productos)
print("--- FIN ---")

# Consultar todos los productos con precio inferior a 50€
cursor.execute("SELECT * FROM PRODUCTOS where PRECIO < ?", (50,))
productos = cursor.fetchall()
print(productos)
print("--- FIN ---")

# Consultar todos los productos ordenados por descripcion de forma ascendente
cursor.execute("SELECT * FROM PRODUCTOS order by descripcion asc")
productos = cursor.fetchall()
for p in productos:
    print(p)
print("--- FIN ---")

# Consultar todos los productos ordenados por descripcion de forma descendente
cursor.execute("SELECT * FROM PRODUCTOS order by descripcion desc")
productos = cursor.fetchall()
for p in productos:
    print(p)
print("--- FIN ---")

# Mostrar todos los productos que comiencen por R
cursor.execute("SELECT * FROM PRODUCTOS where descripcion LIKE 'R%' ")
productos = cursor.fetchall()
print(productos)
print("--- FIN ---")

''' ************************* Modificar datos *************************** '''
# cambiar el precio de la impresora a 140
query = "update PRODUCTOS set precio=? where descripcion=?"
parametros = (140, "Impresora")
cursor.execute(query, parametros)

# subir un 10% todos los precios
query = "update PRODUCTOS set precio=precio * 1.1"
cursor.execute(query)

''' ************************* Eliminar datos *************************** '''
# Eliminar el teclado
cursor.execute('delete from PRODUCTOS where descripcion = ?', ("Teclado",))

# MUY IMPORTANTE EL COMMIT
conexion.commit()

# Cerrar la conexion
conexion.close()