'''
    Crear la clase Animal con nombre, edad y metodo __str__
    Crear la clase ProductoVenta con codigo, precio y metodo __str__
    Crear la clase Perro que hereda de Animal y ProductoVenta
        con vacunado, sexo y metodo __str__
        
    Crear un objeto de Perro y mostrar sus datos
'''
class Animal: 
    def __init__(self, nombre, edad):
        self.nombre = nombre 
        self.edad = edad
        
    def __str__(self):
        return f"Nombre:{self.nombre}, Edad:{self.edad}"
    
class ProductoVenta:
    def __init__(self, codigo, precio) -> None:
        self.codigo = codigo
        self.precio = precio
        
    def __str__(self) -> str:
        return f"Codigo:{self.codigo}, Precio:{self.precio}"
    
class Perro(Animal, ProductoVenta):
    def __init__(self, nombre, edad, codigo, precio, vacunado, sexo):
        # En herencia multiple no podemos utilizar super()
        Animal.__init__(self, nombre, edad)
        ProductoVenta.__init__(self, codigo, precio)
        self.vacunado = vacunado
        self.sexo = sexo
        
    def __str__(self):
        return f"{Animal.__str__(self)}, {ProductoVenta.__str__(self)}, Vacunado:{self.vacunado}, Sexo:{self.sexo} "
    

perro = Perro("Fifi", 3, "PE-001", 195.90, True, "Macho")
print(perro)