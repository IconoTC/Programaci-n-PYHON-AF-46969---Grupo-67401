class Persona: 
    def __init__(self, nombre: str, edad: int):
        self.nombre = nombre 
        self.edad = edad
        
    def __str__(self):
        return f"Hola, me llamo {self.nombre}, tengo {self.edad} años"
    
class Empleado(Persona):
    def __init__(self, nombre, edad, sueldo):
        # Llamando al constructor de la superclase
        super().__init__(nombre, edad)
        self.sueldo = sueldo
    
    # Sobreescribir un metodo heredado    
    def __str__(self):
        return f"{super().__str__()}, sueldo {self.sueldo}" 
    
    
persona = Persona("Maria", 34)
print(persona)

empleado = Empleado("Antonio", 29, 39000)
print(empleado)