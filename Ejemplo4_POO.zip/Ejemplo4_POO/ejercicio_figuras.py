'''
    Crear la clase Figura con x,y y el metodo calcular_area()
    Crear las clases:
        Circulo que hereda de figura, sobreescribir el metodo calcular_area()
        Rectangulo que hereda de figura, sobreescribir el metodo calcular_area()
        Triangulo que hereda de figura, sobreescribir el metodo calcular_area()
'''
import math

class Figura:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y
        
    def calcular_area(self):
        #print("Calculando area:")
        pass
    
    def __str__(self) -> str:
        return f"[{self.x},{self.y}]"
    
    
class Circulo(Figura):
    def __init__(self, x, y, radio) -> None:
        super().__init__(x, y)
        self.radio = radio
        
    def calcular_area(self):
        #super().calcular_area()
        return math.pi * self.radio ** 2
    
    def __str__(self) -> str:
        return f"{super().__str__()}, radio: {self.radio}" 
    

class Rectangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura
    
    def __str__(self) -> str:
        return f"{super().__str__()}, base: {self.base}, altura: {self.altura}" 
    
    
class Triangulo(Figura):
    def __init__(self, x, y, base, altura) -> None:
        #super().__init__(x, y)
        Figura.__init__(self, x, y)  # necesitamos el puntero self
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura / 2
    
    def __str__(self) -> str:
        return f"{super().__str__()}, base: {self.base}, altura: {self.altura}" 
    
    
circulo = Circulo(10,20, 56.25)
print("Area del circulo:", circulo.calcular_area())
print(circulo)

rectangulo = Rectangulo(10,20, 50,24)
print("Area del rectangulo:", rectangulo.calcular_area())
print(rectangulo)

triangulo = Triangulo(10,20, 50,24)
print("Area del triangulo:", triangulo.calcular_area())
print(triangulo)
