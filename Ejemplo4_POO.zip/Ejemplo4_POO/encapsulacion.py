'''
    Una clase encapsulada tiene todas sus propiedades declaradas como privadas
    y se accede a ellas a través de los metodos get y set publicos
    
    En Python el acceso privado no es una restriccion es mas bien un aviso:
    " No deberias utilizar ese recurso, en vez de No puedes utilizar ese recurso"
'''
class Fecha:
    def __init__(self, dia, mes, anyo) -> None:
        self.set_dia(dia)
        self.set_mes(mes)
        self.set_anyo(anyo)
        
    def get_dia(self) -> int:
        return self.__dia
    
    def set_dia(self, dia: int) -> None:
        # los dias son validos entre 1 y 31
        if dia > 0 and dia <= 31:
            self.__dia = dia
        else:
            self.__dia = 0
            print("Dia no valido")
    
    def get_mes(self):
        return self.__mes
    
    def set_mes(self, mes):
        # los meses son validos entre 1 y 12
        if mes > 0 and mes <= 12:
            self.__mes = mes
        else:
            self.__mes = 0
            print("Mes no valido")
    
    def get_anyo(self):
        return self.__anyo
    
    def set_anyo(self, anyo):
        # los años son validos entre 2024 y 2025
        if anyo == 2024 or anyo == 2025:
            self.__anyo = anyo
        else:
            self.__anyo = 0
            print("Año no valido")
            
    dia = property(get_dia, set_dia)
            
    def __str__(self) -> str:
        return "/".join([str(self.__dia), str(self.__mes), str(self.__anyo)])
    
# Crear fecha erronea
erronea = Fecha(567, -23, 87)
print(erronea)

# Crear fecha correcta
hoy = Fecha(22,10,2024)
print(hoy)

# Acceso a las propiedades privadas
erronea.set_dia(28)
erronea.__mes = 8   # No accedo a la propiedad privada, sino que crea esa propiedad
print(erronea)  # 28/0/0
print(erronea.__mes)  # 8

# Acceder a los recursos privados con name mangling
# objeto._Clase__recursoPrivado
erronea._Fecha__mes = 8
print(erronea)

erronea.dia = 22
print(erronea)  # 22/8/0

erronea.dia = 2267675
print(erronea)  # 0/8/0   # Dia no valido    0/8/0

# Retorna un diccionario con los recursos del objeto
print(erronea.__dict__) # {'_Fecha__dia': 28, '_Fecha__mes': 8, '_Fecha__anyo': 0, '__mes': 8}

# Retorna un diccionario con los recursos de la clase
print(Fecha.__dict__)
'''
    {'__module__': '__main__', 
    '__init__': <function Fecha.__init__ at 0x109718e00>, 
    'get_dia': <function Fecha.get_dia at 0x109718ea0>, 
    'set_dia': <function Fecha.set_dia at 0x109718f40>, 
    'get_mes': <function Fecha.get_mes at 0x109718fe0>, 
    'set_mes': <function Fecha.set_mes at 0x109719080>, 
    'get_anyo': <function Fecha.get_anyo at 0x109719120>, 
    'set_anyo': <function Fecha.set_anyo at 0x1097191c0>, 
    '__str__': <function Fecha.__str__ at 0x109719260>, 
    '__dict__': <attribute '__dict__' of 'Fecha' objects>, 
    '__weakref__': <attribute '__weakref__' of 'Fecha' objects>, 
    '__doc__': None}
'''