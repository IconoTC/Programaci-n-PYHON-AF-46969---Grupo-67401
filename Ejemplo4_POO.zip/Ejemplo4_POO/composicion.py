class Direccion:
    def __init__(self, calle, numero, poblacion) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def __str__(self) -> str:
        # Mayor, 5 - Madrid
        return f"{self.calle}, {self.numero} - {self.poblacion}"


class Persona: 
    def __init__(self, nombre: str, edad: int, direccion: Direccion):
        self.nombre = nombre 
        self.edad = edad
        self.direccion = direccion
        
    def mostrar_info(self):
        print(f"Hola, me llamo {self.nombre}, tengo {self.edad} años y vivo en {self.direccion}")
        
        
# Crear la direccion de Juan
dir_juan = Direccion("Mayor", 5, "Madrid")

# Crear personas
juan = Persona("Juan", 38, dir_juan)
juan.mostrar_info()

maria = Persona("Maria", 27, Direccion("Diagonal",139,"Barcelona"))
maria.mostrar_info()

# Juan se cambia de casa
juan.direccion.calle = "Castellana"
juan.direccion.numero = 62
juan.mostrar_info()


