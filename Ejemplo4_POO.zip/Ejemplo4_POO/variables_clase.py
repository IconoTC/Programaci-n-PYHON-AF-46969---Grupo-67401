class Ejemplo:
    # Variable de clase; solo existe una copia y reside en la clase
    contador = 0
     
    def __init__(self, numero) -> None:
        # Variables de instancia; hay una copia en cada instancia
        self.numero = numero
        Ejemplo.contador += 1
    
    # Metodo de instancia    
    def mostrar(self):
        pass
    
    # Metodo sin (self) es un metodo de clase
    def metodo2():
        return Ejemplo.contador
        
        
ej1 = Ejemplo(4)
print(ej1.numero)
print(ej1.contador)
print(Ejemplo.contador)  # 1

ej2 = Ejemplo(7)
print(Ejemplo.contador)  # 2 

ej3 = Ejemplo(2)
print(Ejemplo.metodo2())  # 3