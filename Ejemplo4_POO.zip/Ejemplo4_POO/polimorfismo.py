class Animal:         
    def sonido(self):
        print("Los animales emiten un sonido")
        
class Perro(Animal):
    def sonido(self):
        print("Guau Guau")
        
class Gato(Animal):
    def sonido(self):
        print("Miau Miau")
        
class Vaca(Animal):
    def sonido(self):
        print("Muuu Muuu")
        
        
def emitir_sonido(animal):
    animal.sonido()

animales = [Animal(), Perro(), Gato(), Vaca()]  
for animal in animales:  
    emitir_sonido(animal)