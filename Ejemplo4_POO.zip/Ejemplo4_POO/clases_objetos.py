class Persona:
    
    '''
    # contructor por defecto
    def __init__(self) -> None:
        pass
    '''
    
    # Python no admite sobrecarga de constructores
    # El puntero self debe ser el primer argumento
    def __init__(self, nombre="", edad=0):
        # En el constructor o inicializador se crean las variables de instancia
        self.nombre = nombre    # variables publicas
        self.edad = edad
        
    def mostrar_info(self):
        print(f"Hola, me llamo {self.nombre} y tengo {self.edad} años")
    
    
# Crear objeto o instancia de Persona
p1 = Persona()
print(p1)   # <__main__.Persona object at 0x109405bb0>

p2 = Persona("Juan", 27)
print(p2)    # <__main__.Persona object at 0x1083b1d00>
p2.mostrar_info()

# Los atributos o propiedades o variables de instancia son publicos
p2.edad += 1
p2.mostrar_info()