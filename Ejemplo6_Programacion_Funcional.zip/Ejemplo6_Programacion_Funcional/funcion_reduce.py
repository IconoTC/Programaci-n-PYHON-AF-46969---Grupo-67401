# import modulo
import math
math.pi

# from modulo import recurso
from math import pi
pi

''' Para utilizar reduce necesitamos importarlo  '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]

# suma de todos los numeros
def sumar(acumulado, numero):
    # la primera vez que se invoca pasa 2 numeros: acumulado=3 y numero=8
    return acumulado + numero

print("Suma:", reduce(sumar, numeros))


# Ejemplo 2
dias = ['lunes','martes','miercoles','jueves','viernes','sabado','domingo']

# retornar una cadena con los dias separados por -
def concatenar(acumulado, dia):
    return acumulado + "-" + dia

print(reduce(concatenar, dias))