# Sintaxis:     lambda parametros : que hacemos con esos parametros

'''  ************************    map    ************************** '''
# Ejemplo 1
numeros = [3,8,4,15,30]
numeros_dobles = list(map(lambda numero: numero * 2, numeros))
print(numeros_dobles)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)
nuevas_notas = dict(map(lambda alumno: (alumno[0], alumno[1]+1), alumnos.items()))
print(nuevas_notas)

# Ejemplo 3
class Persona: 
    def __init__(self, nombre: str, edad: int):
        self.nombre = nombre 
        self.edad = edad
        
    def __str__(self):
        return f"Hola, me llamo {self.nombre}, tengo {self.edad} años"

personas = [Persona('Juan',27), Persona('Maria',19), Persona('Pedro',22)]
personas = list(map(lambda persona: Persona(persona.nombre.upper(), persona.edad + 1), personas))
for p in personas:
    print(p)


'''  ************************    filter    ************************** '''
# Ejemplo 1
numeros = [3,8,4,15,30]
numeros_pares = list(filter(lambda numero: numero % 2 == 0, numeros))
print(numeros_pares)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=4.3, Luis=6.4, Adolfo=3.1)
alumnos_suspensos = dict(filter(lambda alumno: alumno[1] < 5, alumnos.items()))
print(alumnos_suspensos)

# Ejemplo 3
personas = [Persona('Juan',17), Persona('Maria',19), Persona('Pedro',22)]
menores = list(filter(lambda persona: persona.edad < 18, personas))
for p in menores:
    print(p)


'''  ************************    reduce    ************************** '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]
print("Suma:", reduce(lambda acumulado, numero: acumulado + numero, numeros))

# Ejemplo 2
dias = ['lunes','martes','miercoles','jueves','viernes','sabado','domingo']
print(reduce(lambda acumulado, dia: acumulado + "-" + dia, dias))