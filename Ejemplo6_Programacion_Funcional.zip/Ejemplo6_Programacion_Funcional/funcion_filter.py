# Ejemplo 1
numeros = [3,8,4,15,30]

# lista solo con los numeros pares
def solo_pares(numero):
    if numero % 2 == 0:
        return True
    else:
        return False
    
numeros_pares = list(filter(solo_pares, numeros))
print(numeros_pares)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=4.3, Luis=6.4, Adolfo=3.1)

# diccionario solo con los suspensos
def solo_suspensos(alumno):
    if alumno[1] < 5:
        return True
    else:
        return False

alumnos_suspensos = dict(filter(solo_suspensos, alumnos.items()))
print(alumnos_suspensos)

# Ejemplo 3
class Persona: 
    def __init__(self, nombre: str, edad: int):
        self.nombre = nombre 
        self.edad = edad
        
    def __str__(self):
        return f"Hola, me llamo {self.nombre}, tengo {self.edad} años"

personas = [Persona('Juan',17), Persona('Maria',19), Persona('Pedro',22)]

# solo los menores de edad
def solo_menores(persona):
    if persona.edad < 18:
        return True
    else:
        return False
    
menores = list(filter(solo_menores, personas))
for p in menores:
    print(p)