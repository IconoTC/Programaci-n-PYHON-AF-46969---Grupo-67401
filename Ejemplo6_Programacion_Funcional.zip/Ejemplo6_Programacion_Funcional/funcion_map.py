# Ejemplo 1
numeros = [3,8,4,15,30]

def duplicar(numero):
    return numero * 2

numeros_dobles = list(map(duplicar, numeros))
print(numeros_dobles)
print(numeros)   # la lista original permanece intacta

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)

def sumar_punto(alumno):
    return alumno[0], alumno[1] + 1

nuevas_notas = dict(map(sumar_punto, alumnos.items()))
print(nuevas_notas)

# Ejemplo 3
class Persona: 
    def __init__(self, nombre: str, edad: int):
        self.nombre = nombre 
        self.edad = edad
        
    def __str__(self):
        return f"Hola, me llamo {self.nombre}, tengo {self.edad} años"

personas = [Persona('Juan',27), Persona('Maria',19), Persona('Pedro',22)]

def modificar_personas(persona):
    persona.nombre = persona.nombre.upper()
    persona.edad += 1
    return persona

personas = list(map(modificar_personas, personas))
#personas = map(modificar_personas, personas)
print(type(personas))
for p in personas:
    print(p)